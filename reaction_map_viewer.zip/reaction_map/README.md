# CHEM740 Reaction Map – Interactive Viewer

An interactive, physics-based browser viewer for the CHEM740 reaction flowchart,
built on Dash + Cytoscape.js.

---

## Quick start

### 1. Place files

Put these three files in the same directory:

```
reaction_map/
├── app.py
├── requirements.txt
└── CHEM740_ReactionMap.json     ← your Lucidchart export
```

### 2. Install dependencies

```bash
pip install -r requirements.txt
```

If you are on a system Python (no venv):

```bash
pip install --break-system-packages -r requirements.txt
```

Or use a virtual environment (recommended):

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

### 3. Run the app

```bash
python app.py
```

Open **http://localhost:8050** in your browser.

Because the server binds to `0.0.0.0`, any machine on the same
network (e.g. inside the UNR campus LAN) can reach it at:

```
http://<your-linux-machine-IP>:8050
```

---

## Features

| Feature | How to use |
|---|---|
| **Physics layout** | Nodes settle using CoSE-Bilkent force simulation. Change via the Layout dropdown. |
| **Zoom / pan** | Scroll to zoom; click-drag to pan. |
| **Fit all** | Click the **⊡ Fit** button to zoom to fit the entire graph. |
| **Text search** | Type ≥ 2 chars in the search box. All matches are highlighted in amber. |
| **Cycle matches** | Use ◀ ▶ to step through matches; the view animates to each one. |
| **Node detail** | Click any node to open the slide-in panel showing type, connectivity, and metadata slots. |
| **Close panel** | Click ✕ or click the graph background. |

---

## Node color coding

| Color | Meaning |
|---|---|
| 🟢 Green | **Compound** (DataBlockNew) — chemical species / functional group |
| 🔵 Blue | **Reaction / Reagent** (ProcessBlock) — transformation or reagent |
| 🟡 Amber diamond | **Decision** (MergeBlock) — branching condition (e.g. "EWG?", "Order") |

Dashed edges correspond to Open Arrow connectors in Lucidchart (reversible or
equilibrium-type relationships). Edge labels (e.g. "Primary", "Secondary",
"Yes", "No") are shown inline on the arrows.

---

## Adding rich content to nodes

The app already reads four metadata fields per node from the JSON:

```json
"notes":       "Free-text annotation",
"dois":        ["10.1021/jacs.XXXXXX"],
"image_urls":  ["https://..."],
"mol_url":     "https://..."
```

Currently all nodes export with empty arrays/strings from Lucidchart.
You can populate them by either:

**Option A – Edit the JSON directly** (simple):
Find the node by its `id` or `text` field and fill in the fields above.
The app reads the JSON at startup each time, so just restart after editing.

**Option B – Companion metadata CSV** (scalable):
Create a `metadata.csv` with columns:
`node_label, notes, doi1, doi2, image_url, mol_url`
and add a small loader in `app.py` that merges it into `NODE_BY_ID` after
parsing. This keeps the Lucidchart JSON untouched.

---

## Layout options

| Layout | Best for |
|---|---|
| **CoSE-Bilkent** (default) | General exploration — physics simulation, good cluster separation |
| **CoSE** | Faster initial layout on large graphs |
| **Dagre** | Seeing the directed flow top-to-bottom |
| **Breadth-first** | Tracing paths from a root compound |
| **Circle** | Quick overview of node count |
| **Random** | Diagnostic / starting point for manual adjustment |

---

## Extending the app

### Firewall / access
The server already binds to `0.0.0.0:8050`. Campus firewall rules should
allow inbound TCP on port 8050 from the campus subnet. If you want HTTPS,
put the app behind an nginx reverse proxy with a self-signed cert.

### Persistent server (background process)
```bash
nohup python app.py > app.log 2>&1 &
```
Or use `screen` / `tmux` to keep it running after you log out.

### Auto-reload on JSON edits
Change `debug=False` to `debug=True` in `app.py` for hot-reload during development.
Switch back to `False` for production.
